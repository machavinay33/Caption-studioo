package com.captionstudio.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.captionstudio.app.ui.theme.AccentWhite

data class ToolbarAction(val label: String, val icon: ImageVector, val highlight: Boolean = false)

// Order mirrors the reference UI: Audio, Text, Voice, Links, Captions, Filters, Adjust...
val editorTools = listOf(
    ToolbarAction("Audio", Icons.Filled.MusicNote),
    ToolbarAction("Text", Icons.Filled.TextFields),
    ToolbarAction("Voice", Icons.Filled.Mic),
    ToolbarAction("Captions", Icons.Filled.ClosedCaption, highlight = true), // our AI feature
    ToolbarAction("Filters", Icons.Filled.FilterVintage),
    ToolbarAction("Adjust", Icons.Filled.Tune),
)

@Composable
fun BottomToolbar(onToolSelected: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(28.dp)
    ) {
        editorTools.forEach { tool ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .padding(horizontal = 8.dp)
                    .clickable { onToolSelected(tool.label) }
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = tool.label,
                    tint = if (tool.highlight) AccentWhite else AccentWhite.copy(alpha = 0.9f),
                    modifier = Modifier.size(26.dp)
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = tool.label,
                    color = AccentWhite,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
