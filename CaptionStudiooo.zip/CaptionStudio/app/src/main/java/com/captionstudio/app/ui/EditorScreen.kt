package com.captionstudio.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.captionstudio.app.ui.components.BottomToolbar
import com.captionstudio.app.ui.components.TimeRuler
import com.captionstudio.app.ui.components.VideoThumbnailTrack
import com.captionstudio.app.ui.theme.EditorBackground

/**
 * Main video editing screen — layout mirrors the reference CapCut-style interface:
 * top bar (close / project name / export quality / Next), video preview,
 * playback controls + timecode, time ruler, thumbnail timeline, and bottom tool row.
 *
 * This is the screen the user lands on right after picking a video to edit.
 */
@Composable
fun EditorScreen(
    projectName: String = "New project",
    onExport: () -> Unit = {},
    onClose: () -> Unit = {},
    onToolSelected: (String) -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EditorBackground)
    ) {
        EditorTopBar(projectName = projectName, onClose = onClose, onExport = onExport)

        // Video preview area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            // TODO: replace with actual ExoPlayer PlayerView surface bound to the imported video
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .fillMaxHeight(0.9f)
                    .background(Color(0xFF1E1E1E))
            )
        }

        PlaybackRow()

        TimeRuler(totalSeconds = 3)

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Add audio", color = Color.White, fontSize = 14.sp)
        }

        VideoThumbnailTrack(thumbnailCount = 4, onAddClip = {})

        BottomToolbar(onToolSelected = onToolSelected)
    }
}

@Composable
private fun EditorTopBar(projectName: String, onClose: () -> Unit, onExport: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = "Close project",
            tint = Color.White,
            modifier = Modifier.size(24.dp)
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = projectName, color = Color.White, fontSize = 18.sp)
            Icon(
                imageVector = Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                tint = Color.White
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "2K", color = Color.White, fontSize = 15.sp, modifier = Modifier.padding(end = 16.dp))
            Button(
                onClick = onExport,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White)
            ) {
                Text("Next", color = Color.Black)
            }
        }
    }
}

@Composable
private fun PlaybackRow() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("▶", color = Color.White, fontSize = 20.sp)
        Column {
            Text("00:00", color = Color.White, fontSize = 13.sp)
            Text("00:03", color = Color.Gray, fontSize = 13.sp)
        }
        Row {
            Text("↺", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(end = 20.dp))
            Text("↻", color = Color.White, fontSize = 18.sp)
        }
    }
}
