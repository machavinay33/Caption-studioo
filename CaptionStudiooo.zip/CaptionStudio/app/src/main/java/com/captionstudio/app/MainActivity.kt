package com.captionstudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.captionstudio.app.ui.EditorScreen
import com.captionstudio.app.ui.theme.CaptionStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CaptionStudioTheme {
                EditorScreen(
                    onToolSelected = { tool ->
                        // "Captions" opens the AI transcription flow (next milestone).
                        // Other tools (Audio, Text, Voice, Filters) get their own panels later.
                    }
                )
            }
        }
    }
}
