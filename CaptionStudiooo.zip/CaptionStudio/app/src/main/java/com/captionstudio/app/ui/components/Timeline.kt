package com.captionstudio.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.captionstudio.app.ui.theme.EditorSurfaceLight
import com.captionstudio.app.ui.theme.TextSecondary

/**
 * Ruler row showing elapsed seconds — mirrors the tick marks in the reference UI (0s,1s,2s,3s...).
 */
@Composable
fun TimeRuler(totalSeconds: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        for (s in 0..totalSeconds) {
            Text(text = "${s}s", color = TextSecondary, fontSize = 11.sp)
        }
    }
}

/**
 * Thumbnail strip representing the video clip on the timeline, with an "add clip" affordance.
 * thumbnailCount is a placeholder — in the real build this is generated from extracted video frames.
 */
@Composable
fun VideoThumbnailTrack(thumbnailCount: Int, onAddClip: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .background(EditorSurfaceLight),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(thumbnailCount) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(Color(0xFF3A3A3A))
            )
        }
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(Color.White)
                .clickable { onAddClip() },
            contentAlignment = Alignment.Center
        ) {
            Text("+", color = Color.Black, fontSize = 22.sp)
        }
    }
}
