package com.captionstudio.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Core palette — near-black editor background, white accent for primary actions,
// matches the reference CapCut-style interface.
val EditorBackground = Color(0xFF0E0E0E)
val EditorSurface = Color(0xFF1A1A1A)
val EditorSurfaceLight = Color(0xFF2A2A2A)
val AccentWhite = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9B9B9B)

private val DarkColors = darkColorScheme(
    background = EditorBackground,
    surface = EditorSurface,
    primary = AccentWhite,
    onBackground = Color.White,
    onSurface = Color.White,
)

@Composable
fun CaptionStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
